export var slice = Array.prototype.slice;
